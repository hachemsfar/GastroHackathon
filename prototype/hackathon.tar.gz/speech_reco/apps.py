from django.apps import AppConfig


class SpeechRecoConfig(AppConfig):
    name = 'speech_reco'
